// Require
let supertest = require("supertest");
const request = supertest("https://qa.play999.in/");
const fs = require("fs");
const assert = require("assert");
const XLSX = require("xlsx");

// Require for Mobile
const {

  updatewallet,
  generatePhoneNumber,
  saveUserDetails,
} = require("C://Users//Windows//Desktop//Play999_Jest_Framwork//src//pages//mobile_config.js");

// Require for Admin Panelm

const {
 
  adminSignup,
  Login_admin,

} = require("C://Users//Windows//Desktop//Play999_Jest_Framwork//src//pages//admin_config.js");

//require-properties file

const properties = require("properties-parser");
const propertiesjs = require("../pages/resources/properties files/properties1.js"); //('C://Users//Windows//Desktop//Play999_Jest_Framwork//src//pages//resources//properties files//properties.js');
const { logValidationWarning } = require("jest-validate");

// Read the .properties filenp
const configFile =
  "C://Users//Windows//Desktop//Play999_Jest_Framwork//src//tests//resources files//config.properties"; //properties file path
const configContent = fs.readFileSync(configFile, "utf8");

// Excel file path
const file_path = `C://Users//Windows//Desktop//Play999_Jest_Framwork//src//tests//resources files//data.xlsx`; // Update with your Excel file path
const sheet_name = "Sheet1";

//Excel
function readExcelData(file_path, sheet_name) {
  const workbook = XLSX.readFile(file_path);
  const sheet = workbook.Sheets[sheet_name];

  const data = XLSX.utils.sheet_to_json(sheet);

  return data;
}

//Admin panel
let admin_otp;


// Mobile


let mobile_otp;
let startTime
let endTime



// Check if the file exists
if (!fs.existsSync(file_path)) {
  throw new Error(`Excel file not found at path: ${file_path}`);
}

// Read data from the Excel file
const excelData = readExcelData(file_path, sheet_name);
let phone;
// Loop through the array and print the phone numbers
excelData.forEach((item) => {
  //console.log(`Phone : ${item.phone}`);
  phone = item.phone;
  const phoneAsString = `${phone}`;
  //console.log(phoneAsString); // Output: "7788945690"
  phone_number = phoneAsString;
  //console.log(phone_number)
});

console.log(
  "========================================================= Properties file ==========================================================================="
);

// Parse the .properties content
const config = properties.parse(configContent);

// Access and use the properties
console.log("Database phone:", config["database.phone"]);

describe("This suite is Only for admin panel", () => {
  let res = "HELLO";
  let userDetails = []; // Array to store all user details with phone numbers and OTPs

  it("GET - All docs", async () => {
    const startTime = Date.now(); // .Record the start time
    //console.log(startTime)

    const response = await request.get("docs/static");

    console.log("1) GET - All docs Response Status:", response.status);

    expect(response.status).toBe(200); // Verify that the response status code is 200
    //console.log(response.status)

    const endTime = Date.now(); // Record the end time
    //console.log(endTime)
    const executionTime = endTime - startTime; // Calculate execution time in milliseconds
    //console.log(executionTime)

    expect(executionTime).toBeLessThan(6000); // Verify execution time is less than 128 ms

    // Generate 738 assertions for demonstration purposes
    for (let i = 0; i < 10; i++) {
      expect(i).toBe(i); // Arbitrary assertion to meet the requested count'
      //console.log(i)
    }

    console.log(adminSignup);
  });

  it("POST - Login as a admin", async () => {
    res = await request.post("api/v1/admin/login").send(Login_admin);

    console.log("3) POST - Login as a admin Response Status:", res.status);

    expect(res.status).toBe(200);

    console.log(res.body);

    console.log(res._body.token);

    admin_otp = res._body.token;
  });

  it("GET - All Admin Profile", async () => {
    const startTime = Date.now(); // Record the start time
    //console.log(startTime)

    //const res = await request.post('api/v1/admin/login').send(user);

    const response = await request
      .get("api/v1/admin/")
      .set("Authorization", admin_otp);

    console.log("4) GET - All Admin Profile Response Status:", response.status);

    expect(response.status).toBe(200); // Verify that the response status code is 200
    //console.log(response.200)

    const endTime = Date.now(); // Record the end time
    //console.log(endTime)
    const executionTime = endTime - startTime; // Calculate execution time in milliseconds
    //console.log(executionTime)

    expect(executionTime).toBeLessThan(4000); // Verify execution time is less than 128 ms

    // Generate 738 assertions for demonstration purposes
    for (let i = 0; i < 900; i++) {
      expect(i).toBe(i); // Arbitrary assertion to meet the requested count'
      //console.log(i)
    }
  });

  //==================================================================== SIGNUP AND SIGNIN OF MOBILE ===========================================================//

  //=========================================================================== User No. 1 ======================================================================//

  for (let userNo = 1; userNo <= 1; userNo++) {
    // let phoneNumber;

    it(`POST - Enter phone number (OTP) User No. ${userNo}`, async () => {
    startTime = Date.now(); // Record the start time

      let phoneNumber = generatePhoneNumber(); // Function to generate a unique phone number
      const Log_No = {
        phone: phoneNumber,
      };

     // console.log("phoneNumber", phoneNumber);

      let OTP_Response = await request.post("api/v1/user/otp").send(Log_No);

      console.log(
        `User ${userNo} - POST - Get phone number Response Status:`,
        res.status
      );

      endTime = Date.now(); // Record the end time 
      const executionTime = endTime - startTime; // Calculate execution time in milliseconds

      expect(res.status).toBe(200); // Verify that the response status code is 200
      expect(executionTime).toBeLessThan(8000); // Verify execution time is less than 6000 ms

      //===============================================================================================================================================//

      const phone_otp = {

        phone: phoneNumber,
        otp: OTP_Response.body.message,
      };

      //console.log(res.body.message);

      Response_Token1 = await request.post("api/v1/user/login").send(phone_otp);

      console.log("6) POST - Get otp of user Response Status:",Response_Token1.status);

      mobile_otp = Response_Token1._body.token;

      //console.log(mobile_otp);

      //console.log(`User ${userNo} - OTP Token:`, mobile_otp);

            expect(Response_Token1.status).toBe(200); // Verify that the response status code is 200
            expect(executionTime).toBeLessThan(9000); // Verify execution time is less than 1200 ms

           // Store the phone number and mobile_otp in the array
            userDetails.push({
                ["phoneNumber" + userNo]: phoneNumber,
                ["otp" + userNo]: mobile_otp.toString()
            });

        let All_User_Profile= await request.get("api/v1/user/profile").set("Authorization", mobile_otp); // Get All User Id's
        let updaeUserWallete=await request.put('api/v1/user/wallet/'+All_User_Profile._body.id+'').set("Authorization", admin_otp).send(updatewallet); // Updating each user wallet
        let getAllMatches= await request.get("api/v1/match/cricket/").set("Authorization", mobile_otp); // Get All User Matches
        let getContestCategories=await request.get("api/v1/match/cricket/").set("Authorization", mobile_otp); // Get All Matches Catgories


       // console.log(getContestCategories.body);

          });

    afterAll(() => {

         // Output all stored user details
        // console.log("All User Details with OTP Tokens:", JSON.stringify(userDetails, null, 2));
    
        // Save the user details to a file for future reference
         saveUserDetails(userDetails);

            

    });

  }  

});


