const properties = require('properties-parser');
const fs = require('fs');

// Read the .properties file
const configFile = (`C://Users//Windows//Desktop//Play999_Jest_Framwork//src//tests//resources files//config.properties`);
const configContent = fs.readFileSync(configFile, 'utf8');

// Parse the .properties content
const config = properties.parse(configContent);

//Access and use the properties
console.log('Database URL:', config['database.url']);
console.log('Database Username:', config['database.username']);
console.log('Database Password:', config['database.password']);
console.log('App Port:', config['app.port']);
console.log('api phone:', config['api.phone']);
