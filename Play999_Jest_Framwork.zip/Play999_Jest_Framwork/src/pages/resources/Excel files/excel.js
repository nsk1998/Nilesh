const fs = require('fs');
const assert = require('assert');
const XLSX = require('xlsx');

function readExcelData(file_path, sheet_name) {
    const workbook = XLSX.readFile(file_path);
    const sheet = workbook.Sheets[sheet_name];

    const data = XLSX.utils.sheet_to_json(sheet);

    return data;
}

describe('Excel Data Test', () => {
    it('should read data from Excel file and perform validation', () => {
        const file_path = (`C://Users//Windows//Desktop//Play999_Jest_Framwork//src//tests//resources files//data.xlsx`); // Update with your Excel file path
        const sheet_name = 'Sheet1';



        // Check if the file exists
        if (!fs.existsSync(file_path)) {
            throw new Error(`Excel file not found at path: ${file_path}`);
        }


        // Read data from the Excel file
        const excelData = readExcelData(file_path, sheet_name);

        console.log(excelData)

        // Perform assertions or validations
        assert.strictEqual(excelData.length, 3);

        assert.strictEqual(excelData[0].Name, 'Alice');
        assert.strictEqual(excelData[0].Age, 25);
        assert.strictEqual(excelData[0].Gender, 'Female');

        assert.strictEqual(excelData[1].Name, 'Bob');
        assert.strictEqual(excelData[1].Age, 30);
        assert.strictEqual(excelData[1].Gender, 'Male');

        assert.strictEqual(excelData[2].Name, 'Carol');
        assert.strictEqual(excelData[2].Age, 28);
        assert.strictEqual(excelData[2].Gender, 'Female');
    });
});