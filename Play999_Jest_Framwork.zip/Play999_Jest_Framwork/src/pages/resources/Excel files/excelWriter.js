// excelWriter.js
const ExcelJS = require('exceljs');
const fs = require('fs')


function writeExcelFile(filePath, data) {
  const workbook = new ExcelJS.Workbook();
  const worksheet = workbook.addWorksheet('Sheet 1');

  data.forEach((row) => {
    worksheet.addRow(row);
  });

  return workbook.xlsx.writeFile(filePath);
}

module.exports = { writeExcelFile };
