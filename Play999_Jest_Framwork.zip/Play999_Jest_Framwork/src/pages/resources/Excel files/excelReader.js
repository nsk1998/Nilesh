// excelReader.js
const XLSX = require('xlsx');

function readExcelFile(file_path) {
    const workbook = XLSX.readFile(file_path);
    const sheetName = workbook.SheetNames[1]; // Assuming you have one sheet
    const worksheet = workbook.Sheets[sheetName];
    return XLSX.utils.sheet_to_json(worksheet);
}

module.exports = { readExcelFile };
