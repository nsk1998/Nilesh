// Read data from the Excel file
const excelData = readExcelData(file_path, sheet_name);
let phone_number;

// Function to generate a unique identifier (e.g., timestamp)
function generateUniqueIdentifier() {
    const timestamp = Date.now();
    return timestamp.toString();
}

// Loop through the array and print the phone numbers with unique identifiers
excelData.forEach((item) => {
    const originalPhone = item.phone;
    const uniqueIdentifier = generateUniqueIdentifier();
    phone_number = `${originalPhone}${uniqueIdentifier}`;
    console.log(phone_number);
});
