// profile.js

const fs = require("fs");

//===============================================================================================================//

const update_user_profile = {
  "email": "use2@example.com",
  "first_name": "use2",
  "last_name": "user123",
  "date_of_birth": "1991-01-02",
  "gender": "male",
  "app_language": "english",
  "street": "chamtikheda",
  "city": "chittorgarh",
  "pin_code": "string",
  "state": "Rajstan",
  "country": "India"
};

//===================================================================================================================================================================/


const generatedPhoneNumbers = new Set();
const generatedPhoneNumbersArray = [];

function generateUniquePhoneNumber() {
  let phoneNumber;

  do {
    phoneNumber = generateRandomPhoneNumber();
  } while (generatedPhoneNumbers.has(phoneNumber));

  generatedPhoneNumbers.add(phoneNumber);
  return phoneNumber;
}

function generateRandomPhoneNumber() {
  // Generate a random 10-digit phone number with the pattern "7898655465"
  return "7" +
    Math.floor(10000 + Math.random() * 90000).toString() +
    Math.floor(1000 + Math.random() * 9000).toString();
}

// Generate and store 3 different unique phone numbers in an array
for (let i = 0; i < 3; i++) {
  const uniquePhoneNumber = generateUniquePhoneNumber();
  generatedPhoneNumbersArray.push(uniquePhoneNumber);
}

// Access and log each unique phone number individually
phoneNumber = (`${generatedPhoneNumbersArray[0]}`);
phoneNumber2 = (`${generatedPhoneNumbersArray[1]}`);
phoneNumber3 = (`${generatedPhoneNumbersArray[2]}`);


phoneNumber11 = phoneNumber.toString()
phoneNumber22 = phoneNumber2.toString()
phoneNumber33 = phoneNumber3.toString()



// const numberOfRequests = 5; // Change this to the number of PUT requests you want to make
// let newEmail;
// for (let i = 0; i < numberOfRequests; i++) {
//      newEmail = `use2_${i}@example.com`; // Change the email for each iteration
//     // update_user_profile.email = newEmail;
//     console.log(update_user_profile.email)
// }


// const database = {
//     update_different_user_profile_details: [
//         {
//             "email": "user2@example.org",
//             "first_name": "use2",
//             "last_name": "",
//             "date_of_birth": "1991-01-02",
//             "gender": "male",
//             "app_language": "english",
//             "street": "chamtikheda",
//             "city": "chittorgarh",
//             "pin_code": "string",
//             "state": "Rajstan",
//             "country": "India"
//         },
//         {
//             "email": "use2@example.com",
//             "first_name": "use2",
//             "last_name": "",
//             "date_of_birth": "1991-01-02",
//             "gender": "female",
//             "app_language": "english",
//             "street": "chamtikheda",
//             "city": "chittorgarh",
//             "pin_code": "string",
//             "state": "Rajstan",
//             "country": "India"
//         },
//         {
//             "email": "use2@example.com",
//             "first_name": "use2",
//             "last_name": "",
//             "date_of_birth": "1991-01-02",
//             "gender": "male",
//             "app_language": "english",
//             "street": "123 Main Street",
//             "city": "chittorgarh",
//             "pin_code": "string",
//             "state": "Rajstan",
//             "country": "India"
//         }
//     ]
// };

//Admin Panel Data 


//================================================================================================================================================================================//

// Function to generate a unique phone number with the first digit between 7 and 8
function generatePhoneNumber() {
  const firstDigit = Math.floor(Math.random() * 2) + 7; // Generate either 7 or 8
  const remainingDigits = Math.floor(Math.random() * 1000000000).toString().padStart(9, '0'); // Generate remaining 9 digits
  return `${firstDigit}${remainingDigits}`;
}

// Function to save user details to a file
function saveUserDetails(userDetails) {
  return new Promise((resolve, reject) => {
   // console.log(userDetails)
  const filePath = 'C://Users//Windows//Desktop//Play999_Jest_Framwork//src//tests//resources files//userDetails.json'; // Specify the file path where details will be saved
  fs.writeFile(filePath, JSON.stringify(userDetails, null, 2), (err) => {
    if (err) {
    //  console.error('Error writing to file', err);
      reject(err);
    } else {
      //console.log('User details saved successfully');
      resolve();
    }
  });
 
})  
}

const updatewallet=

{
  "balance": "10000",
  "bonus": "10000",
  "winning": "10"
}











//================================================================================================================================================================================//




module.exports = {updatewallet, saveUserDetails, update_user_profile, phoneNumber11,phoneNumber22,phoneNumber33, generatePhoneNumber };
