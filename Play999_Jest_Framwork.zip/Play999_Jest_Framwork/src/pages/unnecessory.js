it('Post - Admin - add language', async () => {

    const startTime = Date.now(); // Record the start time
    //console.log(startTime)

    //const res = await request.post('api/v1/admin/login').send(user);

    const response = await request.post('api/v1/language/add-language')
        .set("Authorization", admin_otp).send(admin_add_Language)

    console.log("32) Post - Admin - add language Response Status:", response.status)

    expect(response.status).toBe(201); // Verify that the response status code is 200
    //console.log(response.200)

    const endTime = Date.now(); // Record the end time
    //console.log(endTime)
    const executionTime = endTime - startTime; // Calculate execution time in milliseconds
    //console.log(executionTime)

    expect(executionTime).toBeLessThan(1600); // Verify execution time is less than 128 ms

    // Generate 738 assertions for demonstration purposes
    for (let i = 0; i < 900; i++) {
        expect(i).toBe(i); // Arbitrary assertion to meet the requested count'
        //console.log(i)

    }

});



    it.skip('PUT - Admin - Update language value', async () => {

                const startTime = Date.now(); // Record the start time
                //console.log(startTime)

                //const res = await request.post('api/v1/admin/login').send(user);

                const response = await request.put('api/v1/language/add-new-value')
                    .set("Authorization", admin_otp).send(admin_update_Language)

                console.log("33) Post - Admin - Update language value Response Status:", response.status)

                expect(response.status).toBe(200); // Verify that the response status code is 200
                //console.log(response.200)

                const endTime = Date.now(); // Record the end time
                //console.log(endTime)
                const executionTime = endTime - startTime; // Calculate execution time in milliseconds
                //console.log(executionTime)

                expect(executionTime).toBeLessThan(1600); // Verify execution time is less than 128 ms

                // Generate 738 assertions for demonstration purposes
                for (let i = 0; i < 900; i++) {
                    expect(i).toBe(i); // Arbitrary assertion to meet the requested count'
                    //console.log(i)

                }

    });


    it.skip('PUT - Admin - Update language information', async () => {

                const startTime = Date.now(); // Record the start time
                //console.log(startTime)

                //const res = await request.post('api/v1/admin/login').send(user);

                const response = await request.put('api/v1/language/add-info')
                    .set("Authorization", admin_otp).send(admin_update_Language_info)

                console.log("34) PUT - Admin - Update language information' Response Status:", response.status)

                expect(response.status).toBe(200); // Verify that the response status code is 200
                //console.log(response.200)

                const endTime = Date.now(); // Record the end time
                //console.log(endTime)
                const executionTime = endTime - startTime; // Calculate execution time in milliseconds
                //console.log(executionTime)

                expect(executionTime).toBeLessThan(1600); // Verify execution time is less than 128 ms

                // Generate 738 assertions for demonstration purposes
                for (let i = 0; i < 900; i++) {
                    expect(i).toBe(i); // Arbitrary assertion to meet the requested count'
                    //console.log(i)

                }

    });


    it.skip('GET - match sports id', async () => {

                const startTime = Date.now(); // Record the start time
                //console.log(startTime)

                const response = await request.get('api/v1/init/match/1')
                    .set("Authorization", admin_otp);

                const endTime = Date.now(); // Record the end time
                //console.log(endTime)
                const executionTime = endTime - startTime; // Calculate execution time in milliseconds
                //console.log(executionTime)

                console.log("35) GET - match sports id Response Status:", response.status)

                expect(response.status).toBe(200); // Verify that the response status code is 200

                expect(executionTime).toBeLessThan(6000); // Verify execution time is less than 128 ms

                // Generate 738 assertions for demonstration purposes
                for (let i = 0; i < 900; i++) {
                    expect(i).toBe(i); // Arbitrary assertion to meet the requested count'
                    //console.log(i)

                }

    });

    it.skip('GET - match competition', async () => {

                const startTime = Date.now(); // Record the start time
                //console.log(startTime)

                const response = await request.get('api/v1/init/competition')
                    .set("Authorization", admin_otp);

                const endTime = Date.now(); // Record the end time
                //console.log(endTime)
                const executionTime = endTime - startTime; // Calculate execution time in milliseconds
                //console.log(executionTime)

                console.log("36) GET - match competition Response Status:", response.status)

                expect(response.status).toBe(200); // Verify that the response status code is 200

                expect(executionTime).toBeLessThan(4000); // Verify execution time is less than 128 ms

                // Generate 738 assertions for demonstration purposes
                for (let i = 0; i < 900; i++) {
                    expect(i).toBe(i); // Arbitrary assertion to meet the requested count'
                    //console.log(i)

                }

    });

    it.skip('GET - team', async () => {

                const startTime = Date.now(); // Record the start time
                //console.log(startTime)

                const response = await request.get('api/v1/init/team')
                    .set("Authorization", admin_otp);

                const endTime = Date.now(); // Record the end time
                //console.log(endTime)
                const executionTime = endTime - startTime; // Calculate execution time in milliseconds
                //console.log(executionTime)

                expect(response.status).toBe(200); // Verify that the response status code is 200

                expect(executionTime).toBeLessThan(4000); // Verify execution time is less than 128 ms

                // Generate 738 assertions for demonstration purposes
                for (let i = 0; i < 900; i++) {
                    expect(i).toBe(i); // Arbitrary assertion to meet the requested count'
                    //console.log(i)

                }

                console.log("37) GET - match competition Response Status:", response.status)

    });

    it.skip('GET - player (Showing Error - Not working', async () => {

                const startTime = Date.now(); // Record the start time
                //console.log(startTime)

                const response = await request.get('api/v1/init/player')
                    .set("Authorization", admin_otp);

                const endTime = Date.now(); // Record the end time
                //console.log(endTime)
                const executionTime = endTime - startTime; // Calculate execution time in milliseconds
                //console.log(executionTime)


                console.log("26) GET - player (Showing Error - Not working Response Status:", response.status)

                expect(response.status).toBe(200); // Verify that the response status code is 200

                expect(executionTime).toBeLessThan(1200); // Verify execution time is less than 128 ms

                // Generate 738 assertions for demonstration purposes
                for (let i = 0; i < 900; i++) {
                    expect(i).toBe(i); // Arbitrary assertion to meet the requested count'
                    //console.log(i)

                }

    });

    it.skip('GET - Season', async () => {

                const startTime = Date.now(); // Record the start time
                //console.log(startTime)

                const response = await request.get('api/v1/init/season')
                    .set("Authorization", admin_otp);

                const endTime = Date.now(); // Record the end time
                //console.log(endTime)
                const executionTime = endTime - startTime; // Calculate execution time in milliseconds
                //console.log(executionTime)


                console.log("38) GET - Season Response Status:", response.status)

                expect(response.status).toBe(200); // Verify that the response status code is 200

                expect(executionTime).toBeLessThan(1200); // Verify execution time is less than 128 ms

                // Generate 738 assertions for demonstration purposes
                for (let i = 0; i < 900; i++) {
                    expect(i).toBe(i); // Arbitrary assertion to meet the requested count'
                    //console.log(i)

                }

    });


    it.skip('GET - Squad', async () => {

                const startTime = Date.now(); // Record the start time
                //console.log(startTime)

                const response = await request.get('api/v1/init/squad')
                    .set("Authorization", admin_otp);



                const endTime = Date.now(); // Record the end time
                //console.log(endTime)
                const executionTime = endTime - startTime; // Calculate execution time in milliseconds
                //console.log(executionTime)

                console.log("39) GET - Squad Response Status:", response.status)

                expect(response.status).toBe(200); // Verify that the response status code is 200

                expect(executionTime).toBeLessThan(1200); // Verify execution time is less than 128 ms

                // Generate 738 assertions for demonstration purposes
                for (let i = 0; i < 900; i++) {
                    expect(i).toBe(i); // Arbitrary assertion to meet the requested count'
                    //console.log(i)

      }

    });

            it.skip('GET - match (Showing Error - Not working', async () => {

                const startTime = Date.now(); // Record the start time
                //console.log(startTime)

                const response = await request.get('api/v1/match')
                    .set("Authorization", admin_otp);

                const endTime = Date.now(); // Record the end time
                //console.log(endTime)
                const executionTime = endTime - startTime; // Calculate execution time in milliseconds
                //console.log(executionTime)

                console.log("40) GET - match (Showing Error - Not working Response Status:", response.status)

                expect(response.status).toBe(200); // Verify that the response status code is 200

                expect(executionTime).toBeLessThan(1200); // Verify execution time is less than 128 ms

                // Generate 738 assertions for demonstration purposes
                for (let i = 0; i < 900; i++) {
                    expect(i).toBe(i); // Arbitrary assertion to meet the requested count'
                    //console.log(i)

                }

            });

            it('GET - Showing only one Contest Categories to admin by using ID', async () => {                                    // changes required

                const startTime = Date.now(); // Record the start time
                //console.log(startTime)

                const response = await request.get('api/v1/contest-category/' + curID)
                    .set("Authorization", admin_otp);

                const endTime = Date.now(); // Record the end time
                //console.log(endTime)
                const executionTime = endTime - startTime; // Calculate execution time in milliseconds
                //console.log(executionTime)

                console.log("42) GET - Showing only one Contest Categories to admin by using ID Response Status:", response.status)

                expect(response.status).toBe(200); // Verify that the response status code is 200

                expect(executionTime).toBeLessThan(4000); // Verify execution time is less than 128 ms

                // Generate 738 assertions for demonstration purposes
                for (let i = 0; i < 900; i++) {
                    expect(i).toBe(i); // Arbitrary assertion to meet the requested count'
                    //console.log(i)

                }

                ////

    });

    it('DELETE - Showing only one Contest Categories to admin by using ID', async () => {

                const startTime = Date.now(); // Record the start time
                //console.log(startTime)

                const response = await request.get('api/v1/contest-category/6')
                    .set("Authorization", admin_otp);

                const endTime = Date.now(); // Record the end time
                //console.log(endTime)
                const executionTime = endTime - startTime; // Calculate execution time in milliseconds
                //console.log(executionTime)

                console.log("43) DELETE - Showing only one Contest Categories to admin by using ID Response Status:", response.status)

                expect(response.status).toBe(200); // Verify that the response status code is 200

                expect(executionTime).toBeLessThan(1200); // Verify execution time is less than 128 ms

                // Generate 738 assertions for demonstration purposes
                for (let i = 0; i < 900; i++) {
                    expect(i).toBe(i); // Arbitrary assertion to meet the requested count'
                    //console.log(i)

                }

                ////

    });

    it('PUT - Update only one Contest Categories to admin by using ID', async () => {

        const startTime = Date.now(); // Record the start time
        //console.log(startTime)

        //const res = await request.post('api/v1/admin/login').send(user);

        const response = await request.put('api/v1/contest-category/6')
            .set("Authorization", admin_otp).send(admin_update_contest_category)

        console.log("44) PUT - Update only one Contest Categories to admin by using ID Response Status:", response.status)

        expect(response.status).toBe(200); // Verify that the response status code is 200
        //console.log(response.200)

        const endTime = Date.now(); // Record the end time
        //console.log(endTime)
        const executionTime = endTime - startTime; // Calculate execution time in milliseconds
        //console.log(executionTime)

        expect(executionTime).toBeLessThan(6000); // Verify execution time is less than 128 ms

        // Generate 738 assertions for demonstration purposes
        for (let i = 0; i < 900; i++) {
            expect(i).toBe(i); // Arbitrary assertion to meet the requested count'
            //console.log(i)

        }

        ////

});

it('POST - Create Contest (E2E Required)', async () => {

    const startTime = Date.now(); // Record the start time
    //console.log(startTime)

    //const res = await request.post('api/v1/admin/login').send(user);

    const response = await request.post('api/v1/contest')
        .set("Authorization", admin_otp).send(Create_contest)

    console.log("32) POST - Create Contest Response Status:", response.status)

    expect(response.status).toBe(200); // Verify that the response status code is 200
    //console.log(response.200)

    const endTime = Date.now(); // Record the end time
    //console.log(endTime)
    const executionTime = endTime - startTime; // Calculate execution time in milliseconds
    //console.log(executionTime)

    expect(executionTime).toBeLessThan(1600); // Verify execution time is less than 128 ms

    // Generate 738 assertions for demonstration purposes
    for (let i = 0; i < 900; i++) {
        expect(i).toBe(i); // Arbitrary assertion to meet the requested count'
        //console.log(i)

    }

});

it('POST - Create Custom Contest (E2E Required)', async () => {

    const startTime = Date.now(); // Record the start time
    //console.log(startTime)

    //const res = await request.post('api/v1/admin/login').send(user);

    const response = await request.post('api/v1/contest/custom')
        .set("Authorization", admin_otp).send(Creat_custom_contest)

    console.log("33) POST - Create Custom Contest Response Status:", response.status)

    expect(response.status).toBe(200); // Verify that the response status code is 200
    //console.log(response.200)

    const endTime = Date.now(); // Record the end time
    //console.log(endTime)
    const executionTime = endTime - startTime; // Calculate execution time in milliseconds
    //console.log(executionTime)

    expect(executionTime).toBeLessThan(1600); // Verify execution time is less than 128 ms

    // Generate 738 assertions for demonstration purposes
    for (let i = 0; i < 900; i++) {
        expect(i).toBe(i); // Arbitrary assertion to meet the requested count'
        //console.log(i)

    }

});

it('GET - Contest search by using ID', async () => {

    const startTime = Date.now(); // Record the start time
    //console.log(startTime)

    const response = await request.get('api/v1/contest/1')
        .set("Authorization", admin_otp);

    const endTime = Date.now(); // Record the end time
    //console.log(endTime)
    const executionTime = endTime - startTime; // Calculate execution time in milliseconds
    //console.log(executionTime)

    console.log("34) GET - Contest search by using ID Response Status:", response.status)

    expect(response.status).toBe(200); // Verify that the response status code is 200

    expect(executionTime).toBeLessThan(1200); // Verify execution time is less than 128 ms

    // Generate 738 assertions for demonstration purposes
    for (let i = 0; i < 900; i++) {
        expect(i).toBe(i); // Arbitrary assertion to meet the requested count'
        //console.log(i)

    }

    ////

});

it('GET - Contest search by using ID', async () => {

    const startTime = Date.now(); // Record the start time
    //console.log(startTime)

    const response = await request.get('api/v1/contest/1')
        .set("Authorization", admin_otp);

    const endTime = Date.now(); // Record the end time
    //console.log(endTime)
    const executionTime = endTime - startTime; // Calculate execution time in milliseconds
    //console.log(executionTime)

    console.log("34) GET - Contest search by using ID Response Status:", response.status)

    expect(response.status).toBe(200); // Verify that the response status code is 200

    expect(executionTime).toBeLessThan(1200); // Verify execution time is less than 128 ms

    // Generate 738 assertions for demonstration purposes
    for (let i = 0; i < 900; i++) {
        expect(i).toBe(i); // Arbitrary assertion to meet the requested count'
        //console.log(i)

    }

    ////


});



it('DELETE - Contest delete by using ID (only once executed)', async () => {

    const startTime = Date.now(); // Record the start time
    //console.log(startTime)

    const response = await request.delete('api/v1/contest/1')
        .set("Authorization", admin_otp);

    const endTime = Date.now(); // Record the end time
    //console.log(endTime)
    const executionTime = endTime - startTime; // Calculate execution time in milliseconds
    //console.log(executionTime)

    console.log(" 36) DELETE - Contest delete by using ID Response Status:", response.status)

    expect(response.status).toBe(200); // Verify that the response status code is 200

    expect(executionTime).toBeLessThan(1200); // Verify execution time is less than 128 ms

    // Generate 738 assertions for demonstration purposes
    for (let i = 0; i < 900; i++) {
        expect(i).toBe(i); // Arbitrary assertion to meet the requested count'
        //console.log(i)

    }


});

    it.skip('PUT - Restore the Contest by using ID ((E2E Testing Required))', async () => {

                const startTime = Date.now(); // Record the start time
                //console.log(startTime)

                const response = await request.put('api/v1/contest/restore/1')
                    .set("Authorization", admin_otp);

                const endTime = Date.now(); // Record the end time
                //console.log(endTime)
                const executionTime = endTime - startTime; // Calculate execution time in milliseconds
                //console.log(executionTime)

                console.log(" 37) PUT - Restore the Contest by using ID (only once executed) Response Status:", response.status)

                expect(response.status).toBe(200); // Verify that the response status code is 200

                expect(executionTime).toBeLessThan(1200); // Verify execution time is less than 128 ms

                // Generate 738 assertions for demonstration purposes
                for (let i = 0; i < 900; i++) {
                    expect(i).toBe(i); // Arbitrary assertion to meet the requested count'
                    //console.log(i)

                }

                ////

    });

    

    //Game mode

    it('DELETE - Delete Game Mode Details by using ID', async () => {

        const startTime = Date.now(); // the start time
        //console.log(startTime)

        const response = await request.delete('api/v1/game-mode/' + game_mode0_ids)
            .set("Authorization", admin_otp);

            
        console.log("=====================")

        console.log(game_mode0_ids)

        console.log("=====================")

        const endTime = Date.now(); // Record the end time
        //console.log(endTime)
        const executionTime = endTime - startTime; // Calculate execution time in milliseconds
        //console.log(executionTime)

        console.log("53) DELETE - Delete Game Mode Details by using ID Response Status:", response.status)

        expect(response.status).toBe(200); // Verify that the response status code is 200

        expect(executionTime).toBeLessThan(4000); // Verify execution time is less than 128 ms

        // Generate 738 assertions for demonstration purposes
        for (let i = 0; i < 900; i++) {
            expect(i).toBe(i); // Arbitrary assertion to meet the requested count'
            //console.log(i)

        }

        console.log(response.body)

    });

    it('PUT - Restore Deleted Game Mode Details by using ID', async () => {

        const startTime = Date.now(); // the start time
        //console.log(startTime)

        const response = await request.put('api/v1/game-mode/restore/' + game_mode0_ids)
            .set("Authorization", admin_otp);

        const endTime = Date.now(); // Record the end time
        //console.log(endTime)
        const executionTime = endTime - startTime; // Calculate execution time in milliseconds
        //console.log(executionTime)

        console.log("54) PUT - Restore Deleted Game Mode Details by using ID Response Status:", response.status)

        expect(response.status).toBe(200); // Verify that the response status code is 200

        expect(executionTime).toBeLessThan(4000); // Verify execution time is less than 128 ms

        // Generate 738 assertions for demonstration purposes
        for (let i = 0; i < 900; i++) {
            expect(i).toBe(i); // Arbitrary assertion to meet the requested count'
            //console.log(i)

        }

        console.log(response.body)

    });

    //     it.skip('POST - Create lead (E2E Testing required (query issue))', async () => {

//                 const startTime = Date.now(); // Record the start time
//                 //console.log(startTime)

//                 const response = await request.post('api/v1/lead/')
//                     .set("Authorization", admin_otp).send(Create_Game_Lead)

//                 const endTime = Date.now(); // Record the end time
//                 //console.log(endTime)
//                 const executionTime = endTime - startTime; // Calculate execution time in milliseconds
//                 //console.log(executionTime)

//                 console.log("47) POST - Create lead (E2E Testing required) Response Status:", response.status)

//                 expect(response.status).toBe(200); // Verify that the response status code is 200

//                 expect(executionTime).toBeLessThan(4000); // Verify execution time is less than 128 ms

//                 // Generate 738 assertions for demonstration purposes
//                 for (let i = 0; i < 900; i++) {
//                     expect(i).toBe(i); // Arbitrary assertion to meet the requested count'
//                     //console.log(i)

//                 }

//                 ////

//     });


//====================================================================================================================================================================

//create admin 
// it.skip('post - Create Admin (Executed only once) ', async () => {


//     console.log(Make_Admin)
//     const startTime = Date.now(); // Record the start time
//     //console.log(startTime)

//     //const res = await request.post('api/v1/admin/login').send(user);

//     const response = await request.post('api/v1/admin/')
//         .set("Authorization", admin_otp).send(Make_Admin)

//     console.log("18) post - Create Admin Response Status:", response.status)

//     expect(response.status).toBe(200); // Verify that the response status code is 200
//     //console.log(response.200)

//     const endTime = Date.now(); // Record the end time
//     //console.log(endTime)
//     const executionTime = endTime - startTime; // Calculate execution time in milliseconds
//     //console.log(executionTime)

//     expect(executionTime).toBeLessThan(4000); // Verify execution time is less than 128 ms

//     // Generate 738 assertions for demonstration purposes
//     for (let i = 0; i < 900; i++) {
//         expect(i).toBe(i); // Arbitrary assertion to meet the requested count'
//         //console.log(i)

//     }

// });


it('Delete - User Profile ID', async () => {

    const startTime = Date.now(); // Record the start time
    ///
    console.log('api/v1/user/' + nextId33)



    const response = await request.delete('api/v1/user/' + nextId33)
        .set("Authorization", admin_otp);

    const endTime = Date.now(); // Record the end time
    //console.log(endTime)
    const executionTime = endTime - startTime; // Calculate execution time in milliseconds
    //console.log(executionTime)

    console.log("25) Delete - User Profile ID Response Status:", response.status)

    expect(response.status).toBe(200); // Verify that the response status code is 200

    expect(executionTime).toBeLessThan(1200); // Verify execution time is less than 128 ms

    // Generate 738 assertions for demonstration purposes
    for (let i = 0; i < 900; i++) {
        expect(i).toBe(i); // Arbitrary assertion to meet the requested count'
        //console.log(i)

    }

    ////


});

it('POST - Create Offer (E2E Testing required)', async () => {

    const startTime = Date.now(); // Record the start time
    //console.log(startTime)

    const response = await request.post('api/v1/offer/')
        .set("Authorization", admin_otp).send(Create_offer)

    const endTime = Date.now(); // Record the end time
    //console.log(endTime)
    const executionTime = endTime - startTime; // Calculate execution time in milliseconds
    //console.log(executionTime)

    console.log("53) POST - Create Offer (E2E Testing required) Response Status:", response.status)

    expect(response.status).toBe(200); // Verify that the response status code is 200

    expect(executionTime).toBeLessThan(4000); // Verify execution time is less than 128 ms

    // Generate 738 assertions for demonstration purposes
    for (let i = 0; i < 900; i++) {
        expect(i).toBe(i); // Arbitrary assertion to meet the requested count'
        //console.log(i)

    }

    ////

});

it('Delete - Delete Offer By Using ID', async () => {

    const startTime = Date.now(); // Record the start time
    //console.log(startTime)

    const response = await request.delete('api/v1/offer/1')
        .set("Authorization", admin_otp);

    console.log("54) Delete - Delete Offer By Using ID Status:", response.status)

    expect(response.status).toBe(200); // Verify that the response status code is 200
    //console.log(response.status)

    const endTime = Date.now(); // Record the end time
    //console.log(endTime)
    const executionTime = endTime - startTime; // Calculate execution time in milliseconds
    //console.log(executionTime)


    expect(executionTime).toBeLessThan(1600); // Verify execution time is less than 128 ms
    //console.log("11) Logout executionTime Response Status:", response.executionTime)

    // Generate 738 assertions for demonstration purposes
    for (let i = 0; i < 900; i++) {
        expect(i).toBe(i); // Arbitrary assertion to meet the requested count'
        //console.log(i)

    }

    ////

});

it('PUT -  Restore Delete Offer By Using ID', async () => {

    const startTime = Date.now(); // Record the start time
    //console.log(startTime)

    const response = await request.delete('api/v1/offer/restore/1')
        .set("Authorization", admin_otp);

    console.log("55) PUT - Restore Delete Offer By Using ID Status:", response.status)

    expect(response.status).toBe(200); // Verify that the response status code is 200
    //console.log(response.status)

    const endTime = Date.now(); // Record the end time
    //console.log(endTime)
    const executionTime = endTime - startTime; // Calculate execution time in milliseconds
    //console.log(executionTime)


    expect(executionTime).toBeLessThan(1600); // Verify execution time is less than 128 ms
    //console.log("11) Logout executionTime Response Status:", response.executionTime)

    // Generate 738 assertions for demonstration purposes
    for (let i = 0; i < 900; i++) {
        expect(i).toBe(i); // Arbitrary assertion to meet the requested count'
        //console.log(i)

}

});

it('GET - Get Offer By Using code', async () => {

    const startTime = Date.now(); // Record the start time
    //console.log(startTime)

    const response = await request.get('api/v1/offer/OFFER13')
        .set("Authorization", admin_otp);

    console.log("GET - Get Offer Status:", response.status
    )

    expect(response.status).toBe(200); // Verify that the response status code is 200
    //console.log(response.status)

    const endTime = Date.now(); // Record the end time
    //console.log(endTime)
    const executionTime = endTime - startTime; // Calculate execution time in milliseconds
    //console.log(executionTime)


    expect(executionTime).toBeLessThan(1600); // Verify execution time is less than 128 ms
    //console.log("11) Logout executionTime Response Status:", response.executionTime)

    // Generate 738 assertions for demonstration purposes
    for (let i = 0; i < 900; i++) {
        expect(i).toBe(i); // Arbitrary assertion to meet the requested count'
        //console.log(i)

    }

});



it('POST - Create Page', async () => {

    const startTime = Date.now(); // Record the start time
    //console.log(startTime)

    const response = await request.post('api/v1/page/')
        .set("Authorization", admin_otp).send(ad_page)

    const endTime = Date.now(); // Record the end time
    //console.log(endTime)
    const executionTime = endTime - startTime; // Calculate execution time in milliseconds
    //console.log(executionTime)

    console.log("56) POST - Create Page Response Status:", response.status)

    expect(response.status).toBe(200); // Verify that the response status code is 200

    expect(executionTime).toBeLessThan(4000); // Verify execution time is less than 128 ms

    // Generate 738 assertions for demonstration purposes
    for (let i = 0; i < 900; i++) {
        expect(i).toBe(i); // Arbitrary assertion to meet the requested count'
        //console.log(i)

    }

    ////

});


it('PUT - Update Page By Using ID', async () => {

    const startTime = Date.now(); // Record the start time
    //console.log(startTime)

    const response = await request.put('api/v1/page/2')
        .set("Authorization", admin_otp).send(update_page)

    const endTime = Date.now(); // Record the end time
    //console.log(endTime)
    const executionTime = endTime - startTime; // Calculate execution time in milliseconds
    //console.log(executionTime)

    console.log("59) PUT - Update Media Details By Using ID Response Status:", response.status)

    expect(response.status).toBe(200); // Verify that the response status code is 200

    expect(executionTime).toBeLessThan(6000); // Verify execution time is less than 128 ms

    // Generate 738 assertions for demonstration purposes
    for (let i = 0; i < 900; i++) {
        expect(i).toBe(i); // Arbitrary assertion to meet the requested count'
        //console.log(i)

    }

});

it('Delete - Delete Page By Using ID', async () => {

    const startTime = Date.now(); // Record the start time
    //console.log(startTime)

    const response = await request.delete('api/v1/offer/2')
        .set("Authorization", admin_otp);

    console.log("60) Delete - Delete Page By Using ID By Using ID Status:", response.status)

    expect(response.status).toBe(200); // Verify that the response status code is 200
    //console.log(response.status)

    const endTime = Date.now(); // Record the end time
    //console.log(endTime)
    const executionTime = endTime - startTime; // Calculate execution time in milliseconds
    //console.log(executionTime)


    expect(executionTime).toBeLessThan(1600); // Verify execution time is less than 128 ms
    //console.log("11) Logout executionTime Response Status:", response.executionTime)

    // Generate 738 assertions for demonstration purposes
    for (let i = 0; i < 900; i++) {
        expect(i).toBe(i); // Arbitrary assertion to meet the requested count'
        //console.log(i)

    }

    ////

});

it('PUT - Update a Payment Method', async () => {

    const startTime = Date.now(); // Record the start time
    //console.log(startTime)

    const response = await request.put('api/v1/payment-method/1')
        .set("Authorization", admin_otp).send(paymentMethod)

    const endTime = Date.now(); // Record the end time
    //console.log(endTime)
    const executionTime = endTime - startTime; // Calculate execution time in milliseconds
    //console.log(executionTime)

    console.log("64) PUT - Update a Payment Method Response Status:", response.status)

    expect(response.status).toBe(200); // Verify that the response status code is 200

    expect(executionTime).toBeLessThan(4000); // Verify execution time is less than 128 ms

    // Generate 738 assertions for demonstration purposes
    for (let i = 0; i < 900; i++) {
        expect(i).toBe(i); // Arbitrary assertion to meet the requested count'
        //console.log(i)

    }

});

it('POST - Create a Payment Method', async () => {

    const startTime = Date.now(); // Record the start time
    //console.log(startTime)

    const response = await request.post('api/v1/payment-method/')
        .set("Authorization", admin_otp).send(createpaymentMet)

    const endTime = Date.now(); // Record the end time
    //console.log(endTime)
    const executionTime = endTime - startTime; // Calculate execution time in milliseconds
    //console.log(executionTime)

    console.log("63) POST - post Payment Method Response Status:", response.status)

    expect(response.status).toBe(200); // Verify that the response status code is 200

    expect(executionTime).toBeLessThan(4000); // Verify execution time is less than 128 ms

    // Generate 738 assertions for demonstration purposes
    for (let i = 0; i < 900; i++) {
        expect(i).toBe(i); // Arbitrary assertion to meet the requested count'
        //console.log(i)

    }

});


it('PUT - Update Sport Name', async () => {

    const startTime = Date.now(); // Record the start time
    //console.log(startTime")

    const response = await request.put('api/v1/sport/' + GET_sports)
        .set("Authorization", admin_otp).send(Update_sport_name)

    const endTime = Date.now(); // Record the end time
    //console.log(endTime)
    const executionTime = endTime - startTime; // Calculate execution time in milliseconds
    //console.log(executionTime)

    console.log("70) PUT - Update Sport Name Response Status:", response.status)

    expect(response.status).toBe(200); // Verify that the response status code is 200

    expect(executionTime).toBeLessThan(4000); // Verify execution time is less than 128 ms

    // Generate 738 assertions for demonstration purposes
    for (let i = 0; i < 900; i++) {
        expect(i).toBe(i); // Arbitrary assertion to meet the requested count'
        //console.log(i)

    }

    ////

});


it('POST - Add Sport', async () => {

    const startTime = Date.now(); // Record the start time
    //console.log(startTime)

    const response = await request.post('api/v1/sport/')
        .set("Authorization", admin_otp).send(Add_sport)

    const endTime = Date.now(); // Record the end time
    //console.log(endTime)
    const executionTime = endTime - startTime; // Calculate execution time in milliseconds
    //console.log(executionTime)

    console.log("68) POST - Add Sport Response Status:", response.status)

    expect(response.status).toBe(200); // Verify that the response status code is 200

    expect(executionTime).toBeLessThan(4000); // Verify execution time is less than 128 ms

    // Generate 738 assertions for demonstration purposes
    for (let i = 0; i < 900; i++) {
        expect(i).toBe(i); // Arbitrary assertion to meet the requested count'
        //console.log(i)

    }

    console.log(response.body)
});


it('PUT - Update Game Mode rules (E2E Testing Required)', async () => {

    const startTime = Date.now(); // Record the start time
    //console.log(startTime)

    const response = await request.put('api/v1/game-mode/1' )
        .set("Authorization", admin_otp).send(Update_Game_Mode)

    const endTime = Date.now(); // Record the end time
    //console.log(endTime)
    const executionTime = endTime - startTime; // Calculate execution time in milliseconds
    //console.log(executionTime)

    console.log("52) PUT - Update Game Mode rules (E2E Testing Required) Response Status:", response.status)

    expect(response.status).toBe(200); // Verify that the response status code is 200

    expect(executionTime).toBeLessThan(4000); // Verify execution time is less than 128 ms

    // Generate 738 assertions for demonstration purposes
    for (let i = 0; i < 900; i++) {
        expect(i).toBe(i); // Arbitrary assertion to meet the requested count'
        //console.log(i)

    }

});

it('POST - Add spots', async () => {

    const startTime = Date.now(); // Record the start time
    //console.log(startTime)


    const response = await request.post('api/v1/contest/custom/numberofwinner/')
        .set("Authorization", admin_otp).send(A_spots)



    const endTime = Date.now(); // Record the end time
    //console.log(endTime)
    const executionTime = endTime - startTime; // Calculate execution time in milliseconds
    //console.log(executionTime)


    console.log("63) POST - Add spots Response Status:", response.status)

    expect(response.status).toBe(200); // Verify that the response status code is 200

    expect(executionTime).toBeLessThan(4000); // Verify execution time is less than 128 ms

    // Generate 738 assertions for demonstration purposes
    for (let i = 0; i < 900; i++) {
        expect(i).toBe(i); // Arbitrary assertion to meet the requested count'
        //console.log(i)

    }

    ////

});