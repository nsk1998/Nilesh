
let code;
let udcodes;





//=========================================================================== Admin Signup ===================================================================//

function generateAdminsignup() {
    // Generate a random number to make usernames and passwords unique
    const randomNumber = Math.floor(Math.random() * 10000);

    // Create a unique username and password
    const username = `Admin_${randomNumber}`;
    const password = `Admin@${randomNumber}`;

    return {
        username,
        password,
    };
}

// Example usage to generate unique admin data
const admin1 = generateAdminsignup();
//const admin2 = generateAdminData();

const adminSignup = admin1;


const { currentId} = require('../tests/HomePage.test');


//=========================================================================== Admin Login ===================================================================//

const Login_admin = {

    "username": "Admin_11",
    "password": "Admin@11"

};



const adminid =
{
    "phone": "9595651125",
    "email": "micro1244@gmail.com",
    "password": "stringst",
    "username": "admin_33444",
    "role": "admin",
    "first_name": "",
    "last_name": "",
    "access": {
        "dashboard": true,
        "deposits": true,
        "games": true,
        "offers": true,
        "payment_methods": true,
        "reports": true,
        "settings": true,
        "transactions": true,
        "users": true,
        "withdrawals": true,
        "pages": true,
        "taxes": true
    },
    "is_banned": false
}

//=============================================================================== Make admin =========================================================================//

function generateAdminormakeadmin() {
    const randomNumber = Math.floor(Math.random() * 10000);
    const username = `admin_${randomNumber}`;
    const password = `admin@${randomNumber}`;
    const email = `admin${randomNumber}@gmail.com`;
    const first_name = "string"; // You can modify this if you want to generate random first names
    const last_name = "string"; // You can modify this if you want to generate random last names
    const phone = `986579${randomNumber}`;// You can modify this if you want to generate random phone numbers
    const access = {
        dashboard: true,
        deposits: true,
        games: true,
        offers: true,
        payment_methods: true,
        reports: true,
        settings: true,
        transactions: true,
        users: true,
        withdrawals: true,
        pages: true,
        taxes: true,
    };

    const is_banned = false; // You can modify this if you want to generate random values for 'is_banned'

    return {
        username,
        password,
        email,
        first_name,
        last_name,
        phone,
        access,
        is_banned,
    };
}

// Example usage to generate unique admin data
const Make_Admin = generateAdminormakeadmin();

console.log(Make_Admin);


// {
//     "username": "admin_227",
//     "password": "admin@227",
//     "email": "admin228@gmail.com",
//     "first_name": "string",
//     "last_name": "string",
//     "phone": "8745646591",
//     "access": {
//         "dashboard": true,
//         "deposits": true,
//         "games": true,
//         "offers": true,
//         "payment_methods": true,
//         "reports": true,
//         "settings": true,
//         "transactions": true,
//         "users": true,
//         "withdrawals": true,
//         "pages": true,
//         "taxes": true
//     },
//     "is_banned": true





//======================================================================== Make User =========================================================================//

function generateUniquemakeuser() {
    const randomNumber = Math.floor(Math.random() * 10000);
    const uniqueUsername = `user_${randomNumber}`;
    const uniqueEmail = `user${randomNumber}@example.com`;
    const uniquePhone = `9${Math.floor(Math.random() * 10000000000)}`; // Generates a random 10-digit phone number

    return {
        phone: uniquePhone,
        email: uniqueEmail,
        first_name: "heer",
        last_name: "ranjha",
        date_of_birth: "1995-01-05",
        gender: "male",
        username: uniqueUsername,
        is_banned: false,
    };
}

// Example usage to generate unique user data
const Make_user = generateUniquemakeuser();

console.log(Make_user);


// const Make_user =
// {
//     "phone": "9874917328",
//     "email": "aaaaa@example.com",
//     "first_name": "harshaa",
//     "last_name": "vardhanaa",
//     "date_of_birth": "1995-01-05",
//     "gender": "male",
//     "username": "harsh_3",
//     "is_banned": true
// }

//= =============================================================================================================================================================//

const admin_withdraw =
{
    "amount": 10000,
    "status": "success",
    "remark": "done"
}

const admin_add_Language =
{
    "lang": "malayalam",
    "value": {
        "Home": {
            "tagline": "yava"
        }
    }

}

const admin_update_Language =
{
    "lang": "marathi",
    "value": {
        "Home": {
            "tagline": "j1 kela hota ka"
        }
    }

}

const admin_update_Language_info =
{
    "lang": "marathi",
    "value": {
        "Home": {
            "tagline": "jai jai jai ..... jai hind"
        }
    }

}


const admin_update_contest_category =
{
    "name": "dream_winnerss",
    "status": "active",
    "description": "string",
    "sequence": 0
}

const Create_contest =
{
    "category_id": 0,
    "game_id": 2,
    "sport_id": 1,
    "offer_id": 1,
    "name": "Mega contest",
    "description": "Mega contest",
    "status": "active",
    "is_active": true,
    "bonus_deduction": 0,
    "contest_type": "paid",
    "currency_type": "real",
    "visibility": "public",
    "admin_commission": 10,
    "contest_size": 25000,
    "entry_fee": 99,
    "prize_pool": "2227500",
    "sport_name": "Kabaddi 2",
    "confirmed_winning": true,
    "is_multiple_teams": true,
    "auto_create": true,
    "start_date": "2023-08-28",
    "end_date": "2023-08-31",
    "match_id": 12
}

//======================================================================= Update_User_Detail =====================================================================//

function generateUniqueUserDetails() {
    const randomNumber = Math.floor(Math.random() * 10000);
    const uniqueEmail = `user${randomNumber}@example.com`;
    const uniqueFirstName = `UserFirstName${randomNumber}`;
    const uniqueLastName = `UserLastName${randomNumber}`;
    const uniquePhone = `9${Math.floor(Math.random() * 10000000000)}`;
    const uniqueUsername = `user_${randomNumber}`;
    const uniqueDateOfBirth = generateRandomDateOfBirth();
    const uniqueIsBanned = Math.random() < 0.5; // Randomly assign true or false

    return {
        email: uniqueEmail,
        first_name: uniqueFirstName,
        last_name: uniqueLastName,
        phone: uniquePhone,
        date_of_birth: uniqueDateOfBirth,
        gender: "male", // You can keep this constant or make it random
        username: uniqueUsername,
        is_banned: uniqueIsBanned,
    };
}

function generateRandomDateOfBirth() {
    const year = Math.floor(Math.random() * (2000 - 1970 + 1)) + 1970; // Random year between 1970 and 2000
    const month = Math.floor(Math.random() * 12) + 1; // Random month between 1 and 12
    const day = Math.floor(Math.random() * 28) + 1; // Random day between 1 and 28 (adjust for specific months)

    // Format the date as "YYYY-MM-DD"
    const formattedDate = `${year}-${month.toString().padStart(2, '0')}-${day.toString().padStart(2, '0')}`;

    return formattedDate;
}

// Example usage to generate unique user details
const Update_User_detail = generateUniqueUserDetails();

console.log(Update_User_detail);


// const Update_User_detail =
// {
//     "email": "abc@example.com",
//     "first_name": "harsh",
//     "last_name": "vardhan",
//     "phone": "6578984565",
//     "date_of_birth": "1995-01-04",
//     "gender": "male",
//     "username": "harsh1",
//     "is_banned": false
// }

//======================================================================= Update_User_Detail =====================================================================//

const Creat_custom_contest =
{
    "sport_id": 16,
    "sport_name": "cricket",
    "name": "11_Kings",
    "contest_size": 100000,
    "entry_fee": 11,
    "prize_pool": 990000,
    "max_winners": 11,
    "match_id": 21
}

const Update_contest =
{
    "category_id": 3,
    "game_id": 2,
    "sport_id": 0,
    "offer_id": 1,
    "name": "11_Kings",
    "description": "Isme laga dala toh life jinga lala",
    "status": "active",
    "is_active": true,
    "bonus_deduction": 0,
    "contest_type": "paid",
    "currency_type": "real",
    "visibility": "private",
    "prize_pool": 160,
    "admin_commission": 20,
    "contest_size": 4,
    "entry_fee": 50,
    "confirmed_winning": true,
    "is_multiple_teams": true,
    "auto_create": true,
    "start_date": "2023-08-29",
    "end_date": "2023-08-31"
}

const user_deposit_update =
{

    "status": "approved",
    "remark": "Payement received"

}

const deposit_some_amt =   //Mobile
{
    "amount": 1000,
    "payment_method_id": 13,
    "offer_id": 0
}


const Game_Mode =
{
    "sport_id": 1,
    "game_mode_name": "T7",
    "rules": {

        "wk": 2,
        "all": 3,
        "bat": 2,
        "bowl": 1,
        "substitute": 5

    },
    "credit_points": 83,
    "per_team": 4,
    "is_reverse": false,
    "player_number": 7
}

const Update_Game_Mode =

{
    "sport_id": 15,
    "game_mode_name": "Football",
    "rules": {
        "additionalProp1": {}
    },
    "credit_points": 85,
    "per_team": 11,
    "is_reverse": true,
    "player_number": 22
}


const Create_Game_Lead =
{

    "name": "Tom",

    "title": "ICC World Cup",

    "source": "Twitter",

    "medium": "Social Media"


}

const Upload_Media =
{
    "url": "https://images.entitysport.com/assets/uploads//2023/01/india-4.png"
}


const update_Media =
{


    "name": "newpics.jpeg",
    "caption": "cool pics"

}

const Create_offer =
{
    "name": "offer11",
    "description": "offer11",
    "type": "signup",
    "value": 99999,
    "is_percentage": false,
    "min_deposit": 9999999999999,
    "max_credit": 9999999999999,
    "games_cutoff": 0,
    "code": "offer11",
    "start_date": "2023-10-16",
    "end_date": "2023-10-31",
    "is_bonus": true,
    "is_autoapply": true,
    "is_reusable": true,
    "is_active": true
  }

const ad_page =
{
    "type": "Profiles",
    "heading": "Profile Page ",
    "content": [
        {}
    ]
}

const update_page =
{


    "type": "Profiles",
    "heading": "My Profile info",
    "content": [
        {}
    ]


}

//=======================================================================================================================================================//

function generatePaymentCode(prefix, identifier) {
    return `${prefix}${identifier}`;
}

const prefixes = ["CPE", "BTCE", "ETHE", "LTCE", "XRPE"];
const identifier = "2023";

for (const prefix of prefixes) {
    code = generatePaymentCode(prefix, identifier);
    console.log(`Generated code for ${prefix}: ${code}`);
    // Use the code here for your specific purpose
}


const createpaymentMet =
{

    "name": "UPI",
    "code": code,
    "description": "Refer&Earn",
    "status": "active"

}

const Create_Game_Mode =
{
    "sport_id": 1,
    "game_mode_name": "T7",
    "rules": {

        "wk": 2,
        "all": 3,
        "bat": 2,
        "bowl": 1,
        "substitute": 5

    },
    "credit_points": 83,
    "per_team": 4,
    "is_reverse": false,
    "player_number": 7
}

//====================================================================================================================================//
udcodes = ["UP1001", "UP1002", "UP1003", "UP1004", "UP1005"];

const commonFields = {
    "name": "UPI transfers",
    "description": "Refer&Earn",
    "status": "active"
};

for (const code of udcodes) {
    const paymentMethod = { ...commonFields, code };
    // Now you can use the paymentMethod object with the current code
    console.log("Current Payment Method:");
    console.log(paymentMethod);
}






const A_spots =
{
    "name": "string",
    "category_id": 0,
    "status": "string",
    "type": "string",
    "description": "string",
    "winners": 0,
    "ranges": [
      {
        "st": 0,
        "ed": 0,
        "pr": 0
      }
    ]
  }


const Add_sport =
{
    "sport_name": "cricket",
    "is_active": true,
    "icon": ""
  }

const Update_sport_name =
{
    "sport_name": "Pro_kabbadi"
}

const Update_User_Wallet =

{
    "balance": 1000000000,
    "bonus": 100000000000,
    "winning": 1000000000
}

const User_Add_Bank_Account =

{
    "name": "User3",
    "bank_name": "HDFC Bank",
    "ifsc": "IFSC01234",
    "account": "Saving",
    "type": "bank"
}

const Admin_update_Bank_Account = 

{
    "name": "User10",
    "bank_name": "HDFC Bank",
    "ifsc": "IFSC01234",
    "account": "Saving"

}

const Withdrawn_amt_1000 =
{
    "amount": 1000,
    "account_id": 105
}

module.exports = {createpaymentMet,Withdrawn_amt_1000, Admin_update_Bank_Account, User_Add_Bank_Account,Update_User_Wallet,adminSignup, Login_admin, adminid, Make_Admin, Make_user, admin_withdraw, admin_add_Language, admin_update_Language, admin_update_Language_info, admin_update_contest_category, Create_contest, Creat_custom_contest, Update_contest, user_deposit_update, Create_Game_Mode, Update_Game_Mode, Create_Game_Lead, Upload_Media, update_Media, Create_offer, ad_page, update_page, Add_sport, Update_sport_name, A_spots, Update_User_detail, deposit_some_amt };