package in.page_object.test_utils;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import org.apache.jmeter.util.JMeterUtils;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class ExtentReportGenerator {

    public static void main(String[] args) {
        String jmeterHome = "";
        String csvFile = "";
        
        // Load properties file
        
            Properties properties = new Properties();
           // properties.load(new FileInputStream("C://Users//Windows//Desktop//Jmeter Automation//Play999-Performance_Testing//src//test//java//in//page_object//test_utils//jmeter.properties"));

            jmeterHome = properties.getProperty("jmeter.home");
            csvFile = properties.getProperty("csv.file");
  

        // Set the JMeter home path
        JMeterUtils.setJMeterHome(jmeterHome);
        JMeterUtils.loadJMeterProperties(jmeterHome + "/bin/jmeter.properties");
        JMeterUtils.initLogging(); // Initialize logging
        JMeterUtils.initLocale(); // Initialize locale

        // Initialize the SparkReporter (alternative to HtmlReporter in latest versions)
        ExtentSparkReporter sparkReporter = new ExtentSparkReporter("index.html");
        sparkReporter.config().setTheme(Theme.STANDARD);
        sparkReporter.config().setDocumentTitle("JMeter Automation Report");
        sparkReporter.config().setReportName("HTTP Request Defaults Test");

        // Initialize ExtentReports and attach the SparkReporter
        ExtentReports extent = new ExtentReports();
        extent.attachReporter(sparkReporter);

        // Create a new test
        ExtentTest test = extent.createTest("HTTP Request Defaults Test");

        // Read CSV data file
        try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] fields = line.split(",");
                test.info("Timestamp: " + fields[0] + ", Duration: " + fields[1] + " ms, Request: " + fields[2] + 
                        ", Status: " + fields[3] + " " + fields[4] + ", Thread: " + fields[5] + ", URL: " + fields[13]);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Flush the report
        extent.flush();
    }
}
