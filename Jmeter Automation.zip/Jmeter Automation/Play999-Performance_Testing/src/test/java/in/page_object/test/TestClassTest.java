package in.page_object.test;


import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.AssertJUnit;
import in.page_object.android.TestClassManager;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class TestClassTest {
    private TestClassManager testClassManager;
    private String baseURL;
    private String csvFilePath;
    private String jmeterHome;
    private String phone;

    @BeforeClass
    public void setup() throws IOException {
        // Load properties file
        Properties properties = new Properties();
        properties.load(new FileInputStream("C://Users//Windows//Desktop//Jmeter Automation//Play999-Performance_Testing//src//test//java//in//page_object//test_utils//jmeter.properties"));

        // Assign properties values to class variables
        baseURL = properties.getProperty("baseURL");
        csvFilePath = properties.getProperty("csvFilePath");
        jmeterHome = properties.getProperty("jmeterHome");

        // Initialize TestClassManager and configure test plan
        testClassManager = new TestClassManager();
        testClassManager.initializeJMeter(jmeterHome);
        testClassManager.configureTestPlan(baseURL, csvFilePath, phone);
    }

    @Test
    public void testLoginFunctionality() {
        testClassManager.runTestPlan();

        // Simple check, you might want to analyze results more thoroughly
        // Implement your logic to analyze the result file "test_results.jtl"
        // Here is a basic assertion for demonstration
        AssertJUnit.assertTrue(true);

        // Stop the JMeter engine after the test
        testClassManager.stopTestPlan();
    }
 }

