package in.page_object.test;

import org.apache.jmeter.protocol.http.sampler.HTTPSamplerProxy;
import org.apache.jmeter.protocol.http.control.HeaderManager;
import org.apache.jmeter.protocol.http.control.Header;

public class HttpSamples {

    public static final String DEV_DOMAIN = "qa.play999.in";
    public static final String DEV_ENV = "dev";

    public static HTTPSamplerProxy load() {

        HeaderManager headerManager = new HeaderManager();
        Header header = new Header("Content-Type", "application/json");
        Header header1 = new Header("access-control-allow-origin","*");

        // headerManager.add(new Header(HTTPConstants.HEADER_CONTENT_TYPE, "application/json"));
        headerManager.add(header);

        HTTPSamplerProxy httpSampler = new HTTPSamplerProxy();
        httpSampler.setDomain(DEV_DOMAIN);
        httpSampler.setPort(443);
        httpSampler.setPath("/api/v1/user/otp");
        httpSampler.setMethod("POST");
        httpSampler.setName("Load Dev");
        httpSampler.setFollowRedirects(false);
        httpSampler.setProtocol("https");
        httpSampler.setHeaderManager(headerManager);
        System.out.println(header);
        httpSampler.addNonEncodedArgument("", "{\"phone\":\"9090909090\"}", "");
        httpSampler.setPostBodyRaw(true);
        return httpSampler;

    }
}
