package in.page_object.test;

import org.apache.jmeter.config.Arguments;
import org.apache.jmeter.config.ConfigTestElement;
import org.apache.jmeter.config.gui.ArgumentsPanel;
import org.apache.jmeter.control.LoopController;
import org.apache.jmeter.engine.StandardJMeterEngine;
import org.apache.jmeter.protocol.http.control.Header;
import org.apache.jmeter.protocol.http.control.HeaderManager;
import org.apache.jmeter.protocol.http.sampler.HTTPSamplerBase;
import org.apache.jmeter.protocol.http.sampler.HTTPSamplerProxy;
import org.apache.jmeter.reporters.ResultCollector;
import org.apache.jmeter.samplers.SampleSaveConfiguration;
import org.apache.jmeter.save.SaveService;
import org.apache.jmeter.testelement.TestPlan;
import org.apache.jmeter.testelement.property.PropertyIterator;
import org.apache.jmeter.threads.ThreadGroup;
import org.apache.jmeter.util.JMeterUtils;
import org.apache.jorphan.collections.HashTree;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

public class TestPostMethod {

	 public static void main(String[] args) throws IOException {

	        // Set JMeter home for the JMeter Utils to load
	        String jmeterHome = "path/to/your/jmeter"; // Set this to your JMeter home path
	        File jmeterProperties = new File("C://Program Files//Java//apache-jmeter-5.6.3//apache-jmeter-5.6.3/bin/jmeter.properties");
	        JMeterUtils.setJMeterHome(jmeterHome);
	        JMeterUtils.loadJMeterProperties(jmeterProperties.getPath());
	        JMeterUtils.initLocale();

	        // Initialize JMeter Engine
	        StandardJMeterEngine jmeter = new StandardJMeterEngine();

	        // Create Test Plan
	        TestPlan testPlan = new TestPlan("Dynamic POST Request Test Plan");

	        // Create HTTP Sampler for the POST request
	        HTTPSamplerProxy httpSampler = new HTTPSamplerProxy();
	        httpSampler.setDomain("https://qa.play999.in");
	        httpSampler.setPath("/api/v1/user/otp");
	        httpSampler.setMethod(HTTPSamplerBase.POST);
	        httpSampler.addNonEncodedArgument("", "{\"phone\":\"8888888888\"}", "");
	        httpSampler.setPostBodyRaw(true);

	        // Add headers (optional)
	        HeaderManager headerManager = new HeaderManager();
	        headerManager.add(new Header("content-type", "application/json")); 
	        httpSampler.setHeaderManager(headerManager);

	        // Create Loop Controller
	        LoopController loopController = new LoopController();
	        loopController.setLoops(1);
	        loopController.addTestElement(httpSampler);
	        loopController.setFirst(true);
	        loopController.initialize();

	        // Create Thread Group
	        ThreadGroup threadGroup = new ThreadGroup();
	        threadGroup.setName("Sample Thread Group");
	        threadGroup.setNumThreads(1);
	        threadGroup.setRampUp(1);
	        threadGroup.setSamplerController(loopController);

	        // Create Test Plan Tree
	        HashTree testPlanTree = new HashTree();
	        HashTree threadGroupHashTree = testPlanTree.add(testPlan);
	        threadGroupHashTree.add(threadGroup);
	        threadGroupHashTree.add(httpSampler);

	        // Add Result Collector to save results
	        ResultCollector resultCollector = new ResultCollector();
	        resultCollector.setFilename("test-custom-results.jtl");
	        threadGroupHashTree.add(resultCollector);

	        // Save the test plan
	        SaveService.saveTree(testPlanTree, new FileOutputStream("test-custom-plan.jmx"));

	        // Run the test plan
	        jmeter.configure(testPlanTree);
	        jmeter.run();
	    }

}
