package in.page_object.test;


import org.apache.jmeter.control.LoopController;
import org.apache.jmeter.protocol.http.control.Header;
import org.apache.jmeter.protocol.http.control.HeaderManager;
import org.apache.jmeter.protocol.http.gui.HeaderPanel;
import org.apache.jmeter.reporters.ResultCollector;
import org.apache.jmeter.reporters.Summariser;
import org.apache.jmeter.testelement.TestElement;
import org.apache.jmeter.threads.ThreadGroup;
import org.apache.jmeter.util.JMeterUtils;


public class Utils {

    public static HeaderManager buildHeaders() {

        String hash = null;

//        String pingAuthorizationUrl = "https://company.com/oauth2";
//        String username = "username";
//        String password = "password";
//
        String header = "Bearer " + hash;

        System.out.println("########## " + header);

        HeaderManager manager = new HeaderManager();
//        manager.add(new Header("Authorization", header));
        manager.add(new Header("Content-Type", "application/json"));
        manager.setName("Browser-derived headers");
        manager.setProperty(TestElement.TEST_CLASS, HeaderManager.class.getName());
        manager.setProperty(TestElement.GUI_CLASS, HeaderPanel.class.getName());

        return manager;
    }

    public static ThreadGroup buildThreadGroupWithLoop(int loops, int threads, String name) {
        // Loop Controller
        LoopController loopController = new LoopController();
        loopController.setLoops(loops);
        loopController.setFirst(true);
        loopController.initialize();

        // Thread Group
        ThreadGroup threadGroup = new ThreadGroup();
        threadGroup.setName(name);
        threadGroup.setNumThreads(threads);
        threadGroup.setRampUp(1);
        threadGroup.setEnabled(true);
        threadGroup.setSamplerController(loopController);

        return threadGroup;
    }

    public static ResultCollector buildJMeterSummarizer(String logFileName) {
        // add Summarizer output to get progress in stdout:
        Summariser summariser = null;
        String summariserName = JMeterUtils.getPropDefault("summariser.name", "summary");
        if (summariserName.length() > 0) {
            summariser = new Summariser(summariserName);
        }
        summariser.setEnabled(true);
        // Store execution results into a .csv file
        ResultCollector resultCollector = new ResultCollector(summariser);
        resultCollector.setFilename(logFileName);
        resultCollector.setEnabled(true);
//         resultCollector.setErrorLogging(true);
        return resultCollector;
    }
}
