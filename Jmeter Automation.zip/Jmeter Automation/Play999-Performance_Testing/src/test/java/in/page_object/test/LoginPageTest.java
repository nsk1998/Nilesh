package in.page_object.test;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.Assert;
import in.page_object.android.TestPlanManager;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class LoginPageTest {

    private TestPlanManager testPlanManager;
    private String baseURL;
    private String phone;
    private String csvFilePath;
    private String jmeterHome;

    @BeforeClass
    public void setup() throws IOException {
        // Load properties file
        Properties properties = new Properties();
        properties.load(new FileInputStream("C://Users//Windows//Desktop//Jmeter Automation//Play999-Performance_Testing//src//test//java//in//page_object//test_utils//jmeter.properties"));

        // Assign properties values to class variables
        baseURL = properties.getProperty("baseURL");
        csvFilePath = properties.getProperty("csvFilePath");
        jmeterHome = properties.getProperty("jmeterHome");
        phone = properties.getProperty("phone");

        //System.out.println(baseURL +" "+phone+ "  "+csvFilePath +"  "+jmeterHome);
        // Initialize TestClassManager and configure test plan
        testPlanManager = new TestPlanManager();
        testPlanManager.initializeJMeter(jmeterHome);
        testPlanManager.configureTestPlan(baseURL, csvFilePath,phone);
        
    }
    
    @Test
    public void testLoginFunctionality() {
        testPlanManager.runTestPlan();

        // Simple check, you might want to analyze results more thoroughly
        // Implement your logic to analyze the result file "test_results.jtl"
        // Here is a basic assertion for demonstration
        Assert.assertTrue(true);

        // Stop the JMeter engine after the test
        testPlanManager.stopTestPlan();
    }
}
