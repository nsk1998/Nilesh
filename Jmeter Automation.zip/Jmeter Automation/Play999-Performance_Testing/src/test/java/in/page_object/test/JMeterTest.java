package in.page_object.test;

import org.apache.jmeter.control.LoopController;
import org.apache.jmeter.engine.StandardJMeterEngine;
import org.apache.jmeter.extractor.JSR223PostProcessor;
import org.apache.jmeter.protocol.http.control.Header;
import org.apache.jmeter.protocol.http.control.HeaderManager;
import org.apache.jmeter.protocol.http.sampler.HTTPSamplerProxy;
import org.apache.jmeter.reporters.ResultCollector;
import org.apache.jmeter.save.SaveService;
import org.apache.jmeter.testelement.TestPlan;
import org.apache.jmeter.threads.ThreadGroup;
import org.apache.jmeter.util.JMeterUtils;
import org.apache.jorphan.collections.HashTree;
import org.apache.jorphan.collections.ListedHashTree;

import java.io.FileOutputStream;

public class JMeterTest {

	    private static final String JMETER_HOME = "C://Program Files//Java//apache-jmeter-5.6.3//apache-jmeter-5.6.3";
	    private static final String JMETER_PROPERTIES = JMETER_HOME + "/bin/jmeter.properties";

	    public static void main(String[] args) throws Exception {
	        try{
	            initialize();
	            StandardJMeterEngine jmeterEngine = new StandardJMeterEngine();
	            HashTree testPlanTree = createTestPlan();
	            System.out.println(testPlanTree.toString());
	            SaveService.saveTree(testPlanTree, new FileOutputStream("login_test_plan.jmx"));
	            jmeterEngine.configure(testPlanTree);
	            jmeterEngine.run();
	        }catch (Exception e){
	            System.out.println("Errors");
//	            System.out.println(e.getCause());
	            System.out.println(e.getStackTrace());
	            System.out.println("Errors");
	        }

	    }

	    private static void initialize() throws Exception {
	        JMeterUtils.setJMeterHome(JMETER_HOME);
	        JMeterUtils.loadJMeterProperties(JMETER_PROPERTIES);
	        JMeterUtils.initLogging();
	        JMeterUtils.initLocale();
	    }

	    private static HashTree createTestPlan() {
	        ListedHashTree testPlanTree = new ListedHashTree();

	        TestPlan testPlan = new TestPlan("Stress test");
	        testPlan.setEnabled(true);

	        testPlanTree.add(testPlan);

	        LoopController loopController = new LoopController();
	        loopController.setLoops(1);
	        loopController.setFirst(true);
	        loopController.setName("Loop Controller");

	        ThreadGroup threadGroup = new ThreadGroup();
	        threadGroup.setName("Inbound List tests");
	        threadGroup.setNumThreads(1);
	        threadGroup.setRampUp(1);
	        threadGroup.setSamplerController(loopController);

	        HeaderManager manager = new HeaderManager();
//	        manager.add(new Header("Authorization", header));
	        manager.add(new Header("Content-Type", "application/json; charset=utf-8"));
	        manager.setName("Browser-derived headers");

	        HTTPSamplerProxy samplerProxy = new HTTPSamplerProxy();
	        samplerProxy.setDomain("qa.play999.in");
	      //  samplerProxy.setPort(3000);
	        samplerProxy.setPath("/api/v1/user/otp");
	        samplerProxy.setMethod("POST");
	        samplerProxy.setProtocol("https");
	        samplerProxy.setProxyHost("qa.play999.in");
	        samplerProxy.setHeaderManager(manager);

	        //samplerProxy.addArgument("body","{\"phone\":\"9090909060\"}");

	        //String jsonData = "[{\"phone\":\"9090909060\"}]";
	        samplerProxy.addNonEncodedArgument("","[{\"phone\":\"9090909060\"}]","");
	        //samplerProxy.setPostBodyRaw(true);

	        System.out.println("Smaple Proxy :: "+samplerProxy.toString());
	        ListedHashTree threadGroupHashTree = (ListedHashTree) testPlanTree.add(testPlan, threadGroup);
	        threadGroupHashTree.add(samplerProxy);

//	        threadGroupHashTree.add(samplerProxy, createJSR223PostProcessor());

	        ResultCollector resultCollector = new ResultCollector();
	        testPlanTree.add(testPlan, resultCollector);

	        System.out.println("TestPlan :: "+testPlan);
	        return testPlanTree;
	    }

	    private static JSR223PostProcessor createJSR223PostProcessor() {
	        JSR223PostProcessor postProcessor = new JSR223PostProcessor();
	        postProcessor.setProperty("scriptLanguage", "groovy");
	        postProcessor.setProperty("script", "System.out.println(prev.getResponseDataAsString())");
	        return postProcessor;
	    }
	}




































































































