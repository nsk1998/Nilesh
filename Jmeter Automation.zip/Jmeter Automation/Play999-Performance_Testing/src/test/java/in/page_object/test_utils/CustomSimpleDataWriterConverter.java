package in.page_object.test_utils;

import com.thoughtworks.xstream.converters.Converter;
import com.thoughtworks.xstream.io.HierarchicalStreamReader;
import com.thoughtworks.xstream.io.HierarchicalStreamWriter;
import org.apache.jmeter.visualizers.SimpleDataWriter;

public class CustomSimpleDataWriterConverter implements Converter{
	
    @Override
    public boolean canConvert(Class type) {
        return type.equals(SimpleDataWriter.class);
    }

    @Override
    public void marshal(Object source, HierarchicalStreamWriter writer, com.thoughtworks.xstream.converters.MarshallingContext context) {
        // Implement custom marshalling logic if needed
    }

    @Override
    public Object unmarshal(HierarchicalStreamReader reader, com.thoughtworks.xstream.converters.UnmarshallingContext context) {
        SimpleDataWriter simpleDataWriter = new SimpleDataWriter();
        // Implement custom unmarshalling logic if needed
        return simpleDataWriter;
    }

}
