package in.page_object.android;


import org.apache.jmeter.config.CSVDataSet;
import org.apache.jmeter.extractor.json.jsonpath.JSONPostProcessor;
import org.apache.jmeter.protocol.http.sampler.HTTPSamplerProxy;


public class Testclass {
	
	  public CSVDataSet createCSVDataSet(String filePath) {
	        CSVDataSet csvDataSet = new CSVDataSet();
	        csvDataSet.setProperty("filename", filePath);
	        csvDataSet.setProperty("variableNames", "yourVariableName"); // Add your CSV variable names here
	        csvDataSet.setProperty("delimiter", ","); // Adjust the delimiter if necessary
	        csvDataSet.setProperty("quotedData", "false");
	        csvDataSet.setProperty("recycle", "true");
	        csvDataSet.setProperty("stopThread", "false");
	        csvDataSet.setProperty("shareMode", "shareMode.all");
	        return csvDataSet;
	    }

	    public JSONPostProcessor createGETExtractor() {
	        JSONPostProcessor getExtractor = new JSONPostProcessor();
	        getExtractor.setName("JSON Extractor");
	        getExtractor.setRefNames("refName"); // Set your reference names
	        getExtractor.setJsonPathExpressions("$.yourJsonPath"); // Set your JSON Path expressions
	        getExtractor.setDefaultValues(""); // Set default values if needed
	        return getExtractor;
	    }

}






