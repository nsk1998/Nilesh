package in.page_object.android;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.jmeter.config.Arguments;
import org.apache.jmeter.config.KeystoreConfig;
import org.apache.jmeter.control.LoopController;
import org.apache.jmeter.engine.StandardJMeterEngine;
import org.apache.jmeter.extractor.JSR223PostProcessor;
import org.apache.jmeter.protocol.http.control.CookieManager;
import org.apache.jmeter.protocol.http.control.Header;
import org.apache.jmeter.protocol.http.control.HeaderManager;
import org.apache.jmeter.protocol.http.gui.HeaderPanel;
import org.apache.jmeter.protocol.http.sampler.HTTPSampler;
import org.apache.jmeter.protocol.http.sampler.HTTPSamplerBase;
import org.apache.jmeter.protocol.http.sampler.HTTPSamplerProxy;
import org.apache.jmeter.reporters.ResultCollector;
import org.apache.jmeter.samplers.SampleSaveConfiguration;
import org.apache.jmeter.save.SaveService;
import org.apache.jmeter.testelement.TestElement;
import org.apache.jmeter.testelement.TestPlan;
import org.apache.jmeter.threads.ThreadGroup;
import org.apache.jmeter.util.JMeterUtils;
import org.apache.jorphan.collections.ListedHashTree;
import org.apache.jmeter.protocol.http.util.HTTPConstants;

public class TestPlanManager {

    private StandardJMeterEngine jmeter;
    private ListedHashTree testPlanTree;

    public TestPlanManager() {
        this.jmeter = new StandardJMeterEngine();
        this.testPlanTree = new ListedHashTree();
    }

    public void initializeJMeter(String jmeterHome) {
        JMeterUtils.setJMeterHome(jmeterHome);
        JMeterUtils.loadJMeterProperties(jmeterHome + "/bin/jmeter.properties");
        JMeterUtils.initLocale();
    }

    public void configureTestPlan(String baseURL, String csvFilePath, String phone) {
//        Arguments userDefinedVariables = new Arguments();
//        userDefinedVariables.addArgument("baseURL", baseURL);

        HeaderManager headerManager = new HeaderManager();
        headerManager.setName("HTTP Header Manager");
        headerManager.add(new Header("Content-Type", "application/json"));
//        headerManager.setProperty(TestElement.TEST_CLASS, HeaderManager.class.getName());
//        headerManager.setProperty(TestElement.GUI_CLASS, HeaderPanel.class.getName());

//        String protocaol = HTTPSamplerBase.PROTOCOL_HTTPS;
//        String method = HTTPSamplerBase.METHOD;
        HTTPSampler httpSampler = new HTTPSampler();
        httpSampler.setPath("/api/v1/user/otp");
        httpSampler.setPort(443);
        httpSampler.setDomain("qa.play999.in");
//        httpSampler.setDomain("192.168.29.136");
        httpSampler.setMethod("POST");
//        httpSampler.setProtocol("http");
        httpSampler.setProtocol("https");
//        httpSampler.setPostBodyRaw(true);
        httpSampler.setHeaderManager(headerManager);
//        HTTPSamplerProxy httpRequestDefaults = new HTTPSamplerProxy();
//        httpRequestDefaults.setDomain(baseURL);
//        httpRequestDefaults.setProtocol("https");
//        httpRequestDefaults.setPath("/api/v1/user/otp");
//        httpRequestDefaults.setMethod("POST");
//        httpRequestDefaults.setHeaderManager(headerManager);    // Set the JSON body using setPostBody


        // Construct the JSON body as a valid JSON object
//        String jsonBody = "{\"type\": \"value\", \"phone\": \"9898989898\"}";
//        String jsonBody = "{\"phone\":\""+phone+"\"}"; // JSON formatted string
        String jsonBody = "{\"phone\":\"9090909090\"}";

        // Set the JSON body in the HTTPSamplerProxy
       // httpSampler.addNonEncodedArgument("", jsonBody, "");
        httpSampler.addEncodedArgument("",jsonBody,"");
        httpSampler.setPostBodyRaw(true);

        httpSampler.setThreadName("Thread-Name");
        httpSampler.setContentEncoding("UTF-8");//UTF-8

//        CookieManager cookieManager = new CookieManager();
//        cookieManager.setName("Cookie Manager");
//        httpSampler.setCookieManager(cookieManager);


        LoopController loopController = new LoopController();
        loopController.setLoops(1);
        loopController.setFirst(true);
        loopController.setName("Loop Controller");

        ThreadGroup threadGroup = new ThreadGroup();
        threadGroup.setName("Login Thread Group");
        threadGroup.setNumThreads(1);  // Number of users
        threadGroup.setRampUp(1);
        threadGroup.setSamplerController(loopController);


        ListedHashTree threadGroupHashTree = new ListedHashTree();
        threadGroupHashTree.add(httpSampler, createJSR223PostProcessor());

        TestPlan testPlan = new TestPlan("CustomTest-Plan");
        testPlan.setEnabled(true);
        ListedHashTree testPlanHashTree =  testPlanTree.add(new TestPlan("Login Test Plan"));
        //testPlanHashTree.add(httpSampler);
        testPlanHashTree.add(httpSampler);
//        testPlanHashTree.add(cookieManager);
        testPlanHashTree.add(threadGroup, threadGroupHashTree);

      //   Create and add ResultCollector
        SampleSaveConfiguration sampleSaveConfiguration = new SampleSaveConfiguration();
        sampleSaveConfiguration.setRequestHeaders(true);
        ResultCollector resultCollector = new ResultCollector();
        resultCollector.setFilename("login_results.jtl");
        resultCollector.setSaveConfig(sampleSaveConfiguration);
        testPlanHashTree.add(resultCollector);

        System.out.println("HttpSampler : "+httpSampler.getHeaderManager().getHeaders().get(0));
        System.out.println("TestPlan Tree : "+testPlanTree.getArray());
        try {
           // SaveService.saveTree(testPlanTree, new FileOutputStream("login_test_plan.jmx"));
            File file = new File("login_test_plan.jmx");
            testPlanTree = (ListedHashTree) SaveService.loadTree(file);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    private JSR223PostProcessor createJSR223PostProcessor() {
        JSR223PostProcessor postProcessor = new JSR223PostProcessor();
        postProcessor.setProperty("scriptLanguage", "groovy");
        postProcessor.setProperty("script", "System.out.println(prev.getResponseDataAsString())");
        System.out.println("Post Processor ::  "+postProcessor.getSchema());
        return postProcessor;
    }

    public void runTestPlan() {
        jmeter.configure(testPlanTree);
        jmeter.run();
    }

    public void stopTestPlan() {
        jmeter.stopTest();
    }
}



//    private HTTPSamplerProxy createRequestOTPSampler(String baseURL, String phone) {
//        HTTPSamplerProxy requestOTPSampler = new HTTPSamplerProxy();
//        requestOTPSampler.setName("Request OTP");
//        requestOTPSampler.setProtocol("http"); // Adjust protocol if necessary
//        requestOTPSampler.setDomain(baseURL);
//        requestOTPSampler.setPort(80); // Default HTTP port
//        requestOTPSampler.setPath("/api/v1/user/otp");
//        requestOTPSampler.setMethod("POST");
//        requestOTPSampler.setPostBodyRaw(true);
//        
//        requestOTPSampler.addNonEncodedArgument("", "{\"phone\":\"" + phone + "\"}", ""); // JSON body with dynamic mobile number
//        
//        HeaderManager headerManager = new HeaderManager();
//        Header header = new Header("Content-Type", "application/json");
//        headerManager.add(header);
//        requestOTPSampler.setHeaderManager(headerManager);
//        
//        return requestOTPSampler;
//    }

//    private JSONPostProcessor createOTPExtractor() {
//        JSONPostProcessor otpExtractor = new JSONPostProcessor();
//        otpExtractor.setName("Extract OTP");
//        otpExtractor.setRefNames("otp");
//        otpExtractor.setJsonPathExpressions("$.message"); // Adjust JSON path to match the actual response
//        System.out.println("$.message");
//        otpExtractor.setDefaultValues(""); // Set default values if needed
//        return otpExtractor;
//    }
//
//    private HTTPSamplerProxy createVerifyOTPSampler(String baseURL, String phone) {
//        HTTPSamplerProxy verifyOTPSampler = new HTTPSamplerProxy();
//        verifyOTPSampler.setName("Verify OTP");
//        verifyOTPSampler.setProtocol("https");
//        verifyOTPSampler.setDomain(baseURL);
//        verifyOTPSampler.setPath("/api/v1/user/login");
//        verifyOTPSampler.setMethod("POST");
//        verifyOTPSampler.setPostBodyRaw(true);
//        verifyOTPSampler.addNonEncodedArgument("", "{\"phone\":\"" + phone + "\", \"otp\":\"\"$.message\"\"}", ""); // JSON body with dynamic mobile number and OTP
//        System.out.println("{\"phone\":\"" + phone + "\", \"otp\":\"$.message\"}");
//
//        // Add headers
//        HeaderManager headerManager = new HeaderManager();
//        Header header = new Header("Content-Type", "application/json");
//        headerManager.add(header);
//        verifyOTPSampler.setHeaderManager(headerManager);
//
//        return verifyOTPSampler;
//        
//    }


