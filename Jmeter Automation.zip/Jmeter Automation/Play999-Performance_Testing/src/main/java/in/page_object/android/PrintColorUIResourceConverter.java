//package in.page_object.android;
//
//import java.awt.Color;
//
//import com.thoughtworks.xstream.converters.Converter;
//import com.thoughtworks.xstream.converters.MarshallingContext;
//import com.thoughtworks.xstream.converters.UnmarshallingContext;
//import com.thoughtworks.xstream.io.HierarchicalStreamReader;
//import com.thoughtworks.xstream.io.HierarchicalStreamWriter;
//
//public class PrintColorUIResourceConverter implements Converter {
//
//    @Override
//    public boolean canConvert(Class type) {
//        return type.equals(Color.class);
//    }
//
//    @Override
//    public void marshal(Object source, HierarchicalStreamWriter writer, MarshallingContext context) {
//        Color color = (Color) source;
//        writer.startNode("red");
//        writer.setValue(String.valueOf(color.getRed()));
//        writer.endNode();
//        writer.startNode("green");
//        writer.setValue(String.valueOf(color.getGreen()));
//        writer.endNode();
//        writer.startNode("blue");
//        writer.setValue(String.valueOf(color.getBlue()));
//        writer.endNode();
//    }
//
//    @Override
//    public Object unmarshal(HierarchicalStreamReader reader, UnmarshallingContext context) {
//        reader.moveDown();
//        int red = Integer.parseInt(reader.getValue());
//        reader.moveUp();
//        reader.moveDown();
//        int green = Integer.parseInt(reader.getValue());
//        reader.moveUp();
//        reader.moveDown();
//        int blue = Integer.parseInt(reader.getValue());
//        reader.moveUp();
//        return new Color(red, green, blue);
//    }
//}
