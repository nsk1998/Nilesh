package in.page_object.android;

import org.apache.jmeter.config.Arguments;
import org.apache.jmeter.config.CSVDataSet;
import org.apache.jmeter.config.gui.ArgumentsPanel;
import org.apache.jmeter.control.LoopController;
import org.apache.jmeter.control.gui.TestPlanGui;
import org.apache.jmeter.engine.StandardJMeterEngine;
import org.apache.jmeter.extractor.JSR223PostProcessor;
import org.apache.jmeter.protocol.http.control.Header;
import org.apache.jmeter.protocol.http.control.HeaderManager;
import org.apache.jmeter.protocol.http.control.gui.HttpTestSampleGui;
import org.apache.jmeter.protocol.http.sampler.HTTPSampler;
import org.apache.jmeter.protocol.http.sampler.HTTPSamplerProxy;
import org.apache.jmeter.reporters.ResultCollector;
import org.apache.jmeter.reporters.Summariser;
import org.apache.jmeter.save.SaveService;
import org.apache.jmeter.testbeans.gui.TestBeanGUI;
import org.apache.jmeter.testelement.TestElement;
import org.apache.jmeter.testelement.TestPlan;
import org.apache.jmeter.threads.SetupThreadGroup;
import org.apache.jmeter.threads.ThreadGroup;
import org.apache.jmeter.threads.gui.ThreadGroupGui;
import org.apache.jmeter.util.JMeterUtils;
import org.apache.jorphan.collections.ListedHashTree;

import java.io.FileOutputStream;

public class CustomTestPlanManager {

       // JMeterUtils.loadJMeterProperties("C://Program Files//Java//apache-jmeter-5.6.3//apache-jmeter-5.6.3//bin/jmeter.properties");

    public static void main(String[] argv) throws Exception {

        JMeterUtils.setJMeterHome("C://Program Files//Java//apache-jmeter-5.6.3//apache-jmeter-5.6.3");

        //import the jmeter properties, as is provided
        JMeterUtils.loadJMeterProperties("C://Program Files//Java//apache-jmeter-5.6.3//apache-jmeter-5.6.3//bin//jmeter.properties");
        //Set locale
        JMeterUtils.initLocale();

        //Will be used to compose the testPlan, acts as container
        ListedHashTree hashTree = new ListedHashTree();


        //HTTPSampler acts as the container for the HTTP request to the site.
        HTTPSampler httpHandler = new HTTPSampler();
        httpHandler.setDomain("qa.play999.in");
        httpHandler.setProtocol("https");
        httpHandler.setPort(443);
       httpHandler.setPath("api/v1/user/otp");
        httpHandler.setMethod("post");
        httpHandler.setName("GetOTP");

        Header header = new Header("Content-Type","application/json");
        HeaderManager headerManager = new HeaderManager();
        headerManager.add(header);

        httpHandler.setHeaderManager(headerManager);


        String jsonBody = "{\"phone\":\"9090909090\"}";

        // Set the JSON body in the HTTPSamplerProxy
        // httpSampler.addNonEncodedArgument("", jsonBody, "");
        httpHandler.addEncodedArgument("",jsonBody,"");
        httpHandler.setPostBodyRaw(true);


        //Adding pieces to enable this to be exported to a .jmx and loaded
        //into Jmeter
        httpHandler.setProperty(TestElement.TEST_CLASS, HTTPSamplerProxy.class.getName());
        httpHandler.setProperty(TestElement.GUI_CLASS, HttpTestSampleGui.class.getName());

        //LoopController, handles iteration settings
        LoopController loopController = new LoopController();
        loopController.setLoops(LoopController.INFINITE_LOOP_COUNT);
        loopController.setFirst(true);
        loopController.initialize();

        //Thread groups/user count
        SetupThreadGroup setupThreadGroup = new SetupThreadGroup();
        setupThreadGroup.setName("GoogleTG");
        setupThreadGroup.setNumThreads(1);
        setupThreadGroup.setRampUp(1);
        setupThreadGroup.setSamplerController(loopController);

        //Adding GUI pieces for Jmeter
        setupThreadGroup.setProperty(TestElement.TEST_CLASS, ThreadGroup.class.getName());
        setupThreadGroup.setProperty(TestElement.GUI_CLASS, ThreadGroupGui.class.getName());

        //Create the tesPlan item
        TestPlan testPlan = new TestPlan("GoogleQueryTestPlan");
        //Adding GUI pieces for Jmeter gui
        testPlan.setProperty(TestElement.TEST_CLASS, TestPlan.class.getName());
        testPlan.setProperty(TestElement.GUI_CLASS, TestPlanGui.class.getName());
        testPlan.setUserDefinedVariables((Arguments) new ArgumentsPanel().createTestElement());

        hashTree.add(testPlan);

        ListedHashTree groupTree = (ListedHashTree) hashTree.add(testPlan, setupThreadGroup);
        groupTree.add(httpHandler);

        //Save this tes plan as a .jmx for future reference
        SaveService.saveTree(hashTree, new FileOutputStream("custom_jmxFile.jmx"));

        //Added summarizer for logging meta info
        Summariser summariser = new Summariser("summaryOfResults");

        //Collect results

        ResultCollector resultCollector = new ResultCollector(summariser);

        resultCollector.setFilename("Custom_Results.csv");

        hashTree.add(hashTree.getArray()[0], resultCollector);

        System.out.println(httpHandler.getHeaderManager().get(0));
        StandardJMeterEngine jEngine = new StandardJMeterEngine();

        jEngine.configure(hashTree);

        jEngine.run();

    }

}
