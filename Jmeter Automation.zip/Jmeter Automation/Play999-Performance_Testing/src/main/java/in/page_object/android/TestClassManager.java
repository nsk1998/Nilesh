package in.page_object.android;


import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.jmeter.config.Arguments;
import org.apache.jmeter.config.CSVDataSet;
import org.apache.jmeter.control.LoopController;
import org.apache.jmeter.protocol.http.control.CookieManager;
import org.apache.jmeter.protocol.http.sampler.HTTPSamplerProxy;
import org.apache.jmeter.reporters.ResultCollector;
import org.apache.jmeter.save.SaveService;
import org.apache.jmeter.testelement.TestPlan;
import org.apache.jmeter.threads.ThreadGroup;
import org.apache.jmeter.util.JMeterUtils;
import org.apache.jorphan.collections.ListedHashTree;
import org.apache.jmeter.engine.StandardJMeterEngine;
import org.apache.jmeter.extractor.json.jsonpath.JSONPostProcessor;

public class TestClassManager {

    private StandardJMeterEngine jmeter;
    private ListedHashTree testPlanTree;

    public TestClassManager() {
        this.jmeter = new StandardJMeterEngine();
        this.testPlanTree = new ListedHashTree();
    }

    public void initializeJMeter(String jmeterHome) {
        JMeterUtils.setJMeterHome(jmeterHome);
        JMeterUtils.loadJMeterProperties(jmeterHome + "/bin/jmeter.properties");
        JMeterUtils.initLocale();
    }

    public void configureTestPlan(String baseURL, String csvFilePath,String phone) throws IOException {
        Arguments userDefinedVariables = new Arguments();
        userDefinedVariables.addArgument("baseURL", baseURL);
        System.out.println(baseURL);
        HTTPSamplerProxy httpRequestDefaults = new HTTPSamplerProxy();
        httpRequestDefaults.setDomain("${baseURL}");
        httpRequestDefaults.setProtocol("https");
        httpRequestDefaults.setName("HTTP Request Defaults");


        CookieManager cookieManager = new CookieManager();
        cookieManager.setName("Cookie Manager");

        Testclass testclass = new Testclass();
        CSVDataSet csvDataSet = testclass.createCSVDataSet(csvFilePath);
  //      HTTPSamplerProxy getOTPSampler = testclass.createGetSampler(baseURL);
        JSONPostProcessor otpExtractor = testclass.createGETExtractor();
  //      HTTPSamplerProxy verifyGETSampler = testclass.createVerifyGETSampler(baseURL);

        LoopController loopController = new LoopController();
        loopController.setLoops(1);
        loopController.setFirst(true);
        loopController.setName("Loop Controller");

        ThreadGroup threadGroup = new ThreadGroup();
        threadGroup.setName("Login Thread Group");
        threadGroup.setNumThreads(5);
        threadGroup.setRampUp(1);
        threadGroup.setSamplerController(loopController);

        ListedHashTree threadGroupHashTree = new ListedHashTree();
        threadGroupHashTree.add(csvDataSet);
   //     threadGroupHashTree.add(getOTPSampler, otpExtractor);
  //      threadGroupHashTree.add(verifyGETSampler);

        ListedHashTree testPlanHashTree = (ListedHashTree) testPlanTree.add(new TestPlan("Login Test Plan"));
        testPlanHashTree.add(userDefinedVariables);
        testPlanHashTree.add(httpRequestDefaults);
        testPlanHashTree.add(cookieManager);
        testPlanHashTree.add(threadGroup, threadGroupHashTree);

        // Create and add ResultCollector
        ResultCollector resultCollector = new ResultCollector();
        resultCollector.setFilename("TestClass_results.jtl");
        testPlanHashTree.add(resultCollector);

        SaveService.saveTree(testPlanTree, new FileOutputStream("TestClass_plan.jmx"));
    }

    public void runTestPlan() {
        jmeter.configure(testPlanTree);
        jmeter.run();
    }

    public void stopTestPlan() {
        jmeter.stopTest();
    }
}
